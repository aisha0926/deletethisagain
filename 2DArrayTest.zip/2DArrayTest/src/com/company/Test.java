package com.company;

import java.util.Random;

public class Test {
    public static void main(String[] args) {
        Random rand = new Random();
        rand.nextInt(10);
        System.out.println(rand);
    }
}
